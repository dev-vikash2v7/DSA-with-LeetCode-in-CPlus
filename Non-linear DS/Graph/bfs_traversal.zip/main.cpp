
#include <iostream>
#include<queue>
#include<vector>
using namespace std;


#define N 5 

void BFS(int graph[N][N] , int src ){
    
    queue<int> q ;
    vector<int> visited  ;
    
    q.push(src);
   
    while(! q.empty() ){
        
        int root = q.front();
        cout << root + 1 <<endl;
        visited.push_back(root);
        q.pop();
        
            for(int v = 0 ; v <N ; v++){
                if(find(visited.begin() , visited.end(),  v) == visited.end() && graph[root][v] == 1){
                    q.push(v);
                    visited.push_back(v);
                }
        }
    }
}


int main() 
{
  int graph1[N][N] = {{0, 1, 0, 1, 0},
                        {1, 0, 1, 1, 1},
                        {0, 1, 0, 0, 1},
                        {1, 1, 0, 0, 1},
                        {0, 1, 1, 1, 0}};
                        
                        BFS(graph1 , 0);
    return 0;
}

            /*
          
            
             1 
          /     \
        /        \
        2--------4
       / \       /
      /   \     /
     /     \  / 
    3-------5        
            */